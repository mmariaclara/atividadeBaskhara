using BhaskaraApp;
using System.Data;
namespace TesteConta
{
    [TestClass]
    public class BhaskaraAppUnitTest1
    {
        private Bhaskara bhaskara;

        [TestInitialize]
        public void Inicializar()
        {
            bhaskara = new Bhaskara(1, -3, 2);
        }

        [TestMethod]
        [DataRow(2, 3, 5, 1)]
        [DataRow(1, -4, 0, 1)]
        [DataRow(1, -2, 1, 1)]
        [DataRow(1, 2, 3, 1)]


        public void TesteCalcularDelta(double a, double b, double c, double esperado)
        {
            Bhaskara d = new Bhaskara(a, b, c);
            double obtido = bhaskara.CalcularDelta();

            Assert.AreEqual(esperado, obtido);
        }

        [TestMethod]
        [DataRow(2, 3, 5, false)]
        [DataRow(1, -4, 0, true)]
        [DataRow(1, -2, 1, false)]
        [DataRow(1, 2, 3, null)]

        public void TemRaizesReais(double a, double b, double c, bool esperado)
        {
            bhaskara = new Bhaskara(a, b, c);
            bool obtido = bhaskara.TemRaizesReais();
            Assert.AreEqual(esperado, obtido);
        }

        [TestMethod]
        [DataRow(1.0, -5.0, 6.0, 3.0, 2.0)]
        [DataRow(1.0, -5.0, 6.0, 3.0, 2.0)]
        [DataRow(1.0, 6.0, 8.0, -2.0, -4.0)]
        [DataRow(1.0, -4.0, 0.0, 4.0, 0.0)]
        [DataRow(1.0, 4.0, 5.0, null, null)]

        public void TestarCalcularRaizes(double a, double b, double c, double? x1, double? x2)
        {
            bhaskara = new Bhaskara(a, b, c);
            var (raiz1, raiz2) = bhaskara.CalcularRaizes();

            bool iguais = (x1 == raiz1) && (x2 == raiz2);

            Assert.IsTrue(iguais);

        }


    }
}